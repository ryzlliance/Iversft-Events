<?php
/**
 * Plugin Name: Event Post
 * Plugin URI: N/A
 * Description: This plugin is developed for Iversoft. 
 * Version: 1.0
 * Author: Milan Santos
 * Author URI: N/A
 */
 
 // Should add design 
 
 		//wp_enqueue_script(
//			'classic-editor-plugin',
//			plugins_url( 'https://code.jquery.com/jquery-1.12.4.js'),
//			plugins_url( 'https://code.jquery.com/ui/1.12.1/jquery-ui.js'),
//			plugins_url( 'js/jquery-ui.min.js', __FILE__ ),
//			array( 'wp-element', 'wp-components', 'lodash' ),
//			'1.4',
//			true
//		);
?>

<script type="text/javascript">
//$( function() {
//    $( "#start_date" ).datepicker();
//    $( "#end_date" ).datepicker();
//  } );
</script>

<?php
 
// register custom post type to work with
add_action( 'init', 'rmcc_create_post_type' );
function rmcc_create_post_type() {  
    $labels = array(
        'name' => 'Events',
        'singular_name' => 'Events Item',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Events Item',
        'edit_item' => 'Edit Events Item',
        'new_item' => 'New Events Item',
        'all_items' => 'All Events',
        'view_item' => 'View Events Item',
        'search_items' => 'Search Events',
        'not_found' =>  'No Events Found',
        'not_found_in_trash' => 'No Events found in Trash',
        'parent_item_colon' => '',
        'menu_name' => 'Events',
    );
    register_post_type(
        'events',
        array(
            'labels' => $labels,
            'has_archive' => true,
            'public' => true,
            'hierarchical' => true,
            'supports' => array( 'title', 'editor', 'excerpt', 'custom-fields', 'thumbnail','page-attributes' ),
            'taxonomies' => array( 'post_tag', 'category' ),
            'exclude_from_search' => true,
            'capability_type' => 'post',
        )
    );
}
 
// Type taxonomy
add_action( 'init', 'rmcc_create_taxonomies', 0 );
function rmcc_create_taxonomies() {
    $labels = array(
        'name'              => _x( 'Types', 'taxonomy general name' ),
        'singular_name'     => _x( 'Type', 'taxonomy singular name' ),
        'search_items'      => __( 'Search Types' ),
        'all_items'         => __( 'All Types' ),
        'parent_item'       => __( 'Parent Type' ),
        'parent_item_colon' => __( 'Parent Type:' ),
        'edit_item'         => __( 'Edit Type' ),
        'update_item'       => __( 'Update Type' ),
        'add_new_item'      => __( 'Add New Type' ),
        'new_item_name'     => __( 'New Type' ),
        'menu_name'         => __( 'Types' ),
    );
    register_taxonomy(
        'events',
        array(
            'hierarchical' => true,
            'labels' => $labels,
            'query_var' => true,
            'rewrite' => true,
            'show_admin_column' => true
        )
    );
}

// Meta Box

add_action( 'add_meta_boxes', 'add_events_metaboxes' );

function add_events_metaboxes() {
	add_meta_box(
		'wpt_start_date',
		'Start Date',
		'wpt_start_date',
		'events',
		'normal',
		'default'
	);
	add_meta_box(
		'wpt_end_date',
		'End Date',
		'wpt_end_date',
		'events',
		'normal',
		'default'
	);
}

function wpt_start_date() {
	global $post;

	wp_nonce_field( basename( __FILE__ ), 'event_fields' );
	$start_date = get_post_meta($post->ID, 'start_date', true );
	echo '<input type="text" id="start_date" name="start_date" value="' . esc_textarea( $start_date )  . '" class="widefat">';

}

function wpt_end_date() {
	global $post;

	wp_nonce_field( basename( __FILE__ ), 'event_fields' );
	$end_date = get_post_meta( $post->ID, 'end_date', true );
	echo '<input type="text" id="end_date" name="end_date" value="' . esc_textarea( $end_date )  . '" class="widefat">';

}

/**
 * Save data
 */
function wp_save_events_meta( $post_id, $post ) {

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return $post_id;
	}

	if ( ! isset( $_POST['start_date'] ) || ! wp_verify_nonce( $_POST['event_fields'], basename(__FILE__) ) ) {
		return $post_id;
		
	}
	if ( ! isset( $_POST['end_date'] ) || ! wp_verify_nonce( $_POST['event_fields'], basename(__FILE__) ) ) {
		return $post_id;
	}

	$events_meta['start_date'] = esc_textarea( $_POST['start_date'] );
	$events_meta['end_date'] = esc_textarea( $_POST['end_date'] );
	
	foreach ( $events_meta as $key => $value ) :

		if ( 'revision' === $post->post_type ) {
			return;
		}

		if ( get_post_meta( $post_id, $key, false ) ) {
			update_post_meta( $post_id, $key, $value );
		} else {
			add_post_meta( $post_id, $key, $value);
		}

		if ( ! $value ) {
			delete_post_meta( $post_id, $key );
		}

	endforeach;

}
add_action( 'save_post', 'wp_save_events_meta', 1, 2 );


// create shortcode to list all events which come in blue
add_shortcode( 'list-posts-basic', 'event_list_shortcode' );
function event_list_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'events',
        'posts_per_page' => -1,
        'order' => 'desc',
        'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
        <ul class="events-listing">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
            <li id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h4><?php the_title(); ?></h4>
                <p>Date: <?php echo $start_date = get_post_meta(get_the_ID(), 'start_date', true); ?> - <?php echo $end_date = get_post_meta(get_the_ID(), 'end_date', true); ?>
                </p>
                <p><?php the_content(); ?>
                </p>
            </li>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </ul>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}